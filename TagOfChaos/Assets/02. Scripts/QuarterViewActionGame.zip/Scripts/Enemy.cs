using System.Collections;
using UnityEngine;
using UnityEngine.AI;

public class Enemy : MonoBehaviour, MaterialColorChanage
{
    public enum Type
    {
        A, B, C, D, BoombMonster, FireBallMonster
    };

    [Header("Options")]
    [SerializeField] protected Type enemyType;
    [SerializeField] protected int maxHealth;
    [SerializeField] protected int curHealth;
    [SerializeField] protected float spawnTime;
    [SerializeField] protected int score;

    [Header("Components")]
    [SerializeField] protected Collider meleeArea;
    [SerializeField] protected Collider mainColider;
    [SerializeField] protected GameObject bullet;
    [SerializeField] protected Transform target; // ���� �� ������Ʈ 
    [SerializeField] protected GameObject[] coins;
    [SerializeField] protected GameManager manager;

    protected Renderer[] meshs;
    protected BoxCollider boxCollider;
    protected Rigidbody rigid;
    protected NavMeshAgent nav;
    protected Animator animator;
    protected float time = 0f;

    [SerializeField] protected bool isChase; // �����ϰ� �ִ°�?
    protected bool isAttack; // ������ �ϰ� �ִ°�?
    protected bool isTime;
    protected bool isDead;
    protected bool isHpBar;
    private bool isDestroy = false;
    private bool isBulletDestroy = false;

    protected int ranCoin;
    public int RanCoin => ranCoin;

    public int CurHealth => curHealth;
    public int MaxHealth => maxHealth;
    public bool IsHpBar => isHpBar;
    public GameManager Manager => manager;

    protected virtual void Awake()
    {
        rigid = GetComponent<Rigidbody>();
        boxCollider = GetComponent<BoxCollider>();
        nav = rigid.GetComponent<NavMeshAgent>();
        animator = GetComponentInChildren<Animator>();
        meshs = GetComponentsInChildren<MeshRenderer>();
        if (enemyType != Type.D)
            Invoke("ChaseStart", spawnTime);
    }

    private void Start()
    {
        mainColider.enabled = false;
        curHealth = maxHealth;
    }
    private void FixedUpdate()
    { 
        time += Time.fixedDeltaTime;
        isTime = spawnTime <= time;
        if (isTime)
        {
            mainColider.enabled = true;
        }
        Targetting();
        if(!isDead)
            FreezeVelocity();
    }
    private void Update()
    {
        if (nav.enabled && enemyType != Type.D)
        {
            nav.SetDestination(target.position);
            nav.isStopped = !isChase;
        }
    }

    protected virtual void Targetting()
    {
        float targetRadius = 0f;
        float targetRange = 0f;
        if(!isDead && enemyType != Type.D)
        {
            switch (enemyType)
            {
                case Type.A:
                    targetRadius = 1.5f;
                    targetRange = 3f;
                    break;
                case Type.B:
                    targetRadius = 1f;
                    targetRange = 6f;
                    break;
                case Type.C:
                    targetRadius = 0.5f;
                    targetRange = 25f;
                    break;
                case Type.FireBallMonster:
                    targetRadius = 1.5f;
                    targetRange = 3f;
                    break;
            }

            RaycastHit[] raycastHits =
            Physics.SphereCastAll(transform.position,
                                    targetRadius, transform.forward, targetRange, LayerMask.GetMask("Player"));

            // �������� �ƴѵ�, ���� �ȿ� �÷��̾ Ÿ������ �Ǿ��� ���
            if (raycastHits.Length > 0 && !isAttack && isTime)
            {
                StartCoroutine(Attack());
            }
        }
    }

    protected virtual IEnumerator Attack()
    {
        isChase = false;
        isAttack = true;
        animator.SetBool("isAttack", true);

        switch (enemyType)
        {
            case Type.A:
                if (isDead)
                    break;
                yield return new WaitForSeconds(0.2f);
                meleeArea.enabled = true;

                if (meleeArea == null)
                    break;
                
                yield return new WaitForSeconds(1f);
                meleeArea.enabled = false; // ���� ����
                yield return new WaitForSeconds(1f);
                break;
            case Type.B:
                if (isDead)
                    break;
                // ���� ����
                yield return new WaitForSeconds(0.1f);
                rigid.AddForce(transform.forward * 20, ForceMode.Impulse);
                meleeArea.enabled = true;

                yield return new WaitForSeconds(0.5f);
                rigid.linearVelocity = Vector3.zero;

                meleeArea.enabled = false;

                yield return new WaitForSeconds(2f);
                break;
            case Type.C:
                if (isDead)
                    break;
                yield return new WaitForSeconds(0.5f);
                Bullet enemyCBullet = EnemyBulletObejctPool.Instance.GetEnemyCBulletPool();
                enemyCBullet.transform.position = transform.position;
                enemyCBullet.transform.rotation = transform.rotation;
                Rigidbody rigidBullet = enemyCBullet.GetComponent<Rigidbody>();
                rigidBullet.linearVelocity = transform.forward * 20;
                
                yield return new WaitForSeconds(2f);
                break;
        }
        isChase = true;
        isAttack = false;
        animator.SetBool("isAttack", false);
    }


    public void ChaseStart()
    {
        isChase = true;
        animator.SetBool("isWalk", true);
    }


    public void FreezeVelocity()
    {
        //if (isChase)
        //{
            rigid.linearVelocity = Vector3.zero;
            rigid.angularVelocity = Vector3.zero;
        //}
    }

    private void OnTriggerEnter(Collider other)
    {
        if(other.tag == "Melee")
        {
            Weapon weapon = other.GetComponent<Weapon>();
            curHealth -= weapon.GetDamage();
            // �ǰݽ� �ݵ��ϱ� ���� ����
            Vector3 reactVector = transform.position - other.transform.position;
            StartCoroutine(OnDamage(reactVector, false, weapon.GetDamage()));
        }
        else if (other.tag == "Bullet")
        {
            Bullet bullet = other.GetComponent<Bullet>();

            if(bullet != null)
            {
                curHealth -= bullet.GetDamage();
                Vector3 reactVector = transform.position - other.transform.position;
                bullet.BulletDestroyAfter(bullet);
                StartCoroutine(OnDamage(reactVector, false, bullet.GetDamage()));
            }

        }
    }
    //public void BulletDestroyAfter(Bullet bullet)
    //{
    //    if (isBulletDestroy == true)
    //        return;
    //    isBulletDestroy = true;
    //    BulletObjectPool.ReturnBullet(bullet);
    //}

    //public void SetIsBulletDestroy()
    //{
    //    Debug.Log("isBulletDestroy : " + isBulletDestroy);
    //    isBulletDestroy = false;
    //}


    public void HitByGrenade(Vector3 explosionPos, int damage)
    {
        curHealth -= damage;
        Vector3 reactVec = transform.position - explosionPos;
        StartCoroutine(OnDamage(reactVec, true, damage));
    }


    // �ǰݽ� �̺�Ʈ �Լ�
    protected virtual IEnumerator OnDamage(Vector3 reactVector, bool isGrenade, int damage)
    {
        // �ǰ��� ������ �� �����ϱ�
        foreach(MeshRenderer mesh in meshs)
        {
            if(!mesh.CompareTag("Invisible"))
                mesh.material.color = Color.red;
        }

        DamageText damageText = manager.GetDamageText().GetComponent<DamageText>();
        damageText.SetTarget(this.transform);
        damageText.print(damage.ToString());

        yield return new WaitForSeconds(0.1f);

        if(curHealth > 0)
        {
            foreach(MeshRenderer mesh in meshs)
            {
                if (!mesh.CompareTag("Invisible"))
                    mesh.material.color = Color.white;
            }
        }
        else if(curHealth <= 0)
        {
            isDead = true;
            rigid.constraints = RigidbodyConstraints.FreezeRotationX |
                                RigidbodyConstraints.FreezeRotationY |
                                RigidbodyConstraints.FreezeRotationZ;

            ColorChange(meshs);
                
            curHealth = 0;
            gameObject.layer = 12;
            isChase = false;
            nav.enabled = false;
            animator.SetTrigger("doDie");

            Player player = target.GetComponent<Player>();
            player.SetScore(player.Score + score);
            ranCoin = Random.Range(0, 3);
            GameObject coin = ItemObjectPool.GetCoin(ranCoin);
            coin.transform.position = transform.position;
            coin.transform.rotation = Quaternion.identity;

            Item coinItem = coin.GetComponent<Item>();
            if(coinItem != null)
            {
                coinItem.SetCoinIndexPool(ranCoin);
            }
            switch (enemyType)
            {
                // �ٸ� ��� �˾ƺ���.
                case Type.A:
                    //manager.enemyCntA--;
                    int enemyCntA = manager.EnemyCntA;
                    manager.DecreaseEnemyCount(Type.A, --enemyCntA);
                    break;
                case Type.B:
                    int enemyCntB = manager.EnemyCntB;
                    manager.DecreaseEnemyCount(Type.B, --enemyCntB);
                    break;
                case Type.C:
                    int enemyCntC = manager.EnemyCntC;
                    manager.DecreaseEnemyCount(Type.C, --enemyCntC);
                    break;
                case Type.D:
                    int enemyCntD = manager.EnemyCntD;
                    manager.DecreaseEnemyCount(Type.D, --enemyCntD);
                    break;
            }


            if (isGrenade)
            {
                reactVector = reactVector.normalized;
                reactVector += Vector3.up * 3;

                rigid.freezeRotation = false;
                rigid.AddForce(reactVector * 5, ForceMode.Impulse);
                rigid.AddTorque(reactVector * 15, ForceMode.Impulse);
            }
            else
            {
                reactVector = reactVector.normalized;
                reactVector += Vector3.up;
                rigid.AddForce(reactVector * 5, ForceMode.Impulse);
            }
            rigid.freezeRotation = false;
            Invoke("DieAfterTime", 4f);
        }
    }

    private void DieAfterTime()
    {
        if (isDestroy == true)
            return;
        isDestroy = true;
        EnemyObjectPool.Instance.ReturnEnemy(this);
    }

    public void Initialize(Transform target, GameManager manager)
    {
        this.target = target;
        this.manager = manager;
    }

    public void SetIsHpBar(bool isHpBar)
    {
        this.isHpBar = isHpBar;
    }

    public Type GetEnemyType()
    {
        return enemyType;
    }

    public virtual void ResetState()
    {
        time = 0;
        curHealth = maxHealth;

        foreach (MeshRenderer mesh in meshs)
        {
            if(!mesh.CompareTag("Invisible"))
                mesh.material.color = Color.white;
        }
        
        gameObject.layer = 11;
        
        isChase = false;
        isAttack = false; // ������ �ϰ� �ִ°�?
        isTime = false;
        isDead = false;
        nav.enabled = true;

        rigid.constraints = RigidbodyConstraints.FreezeAll;

        mainColider.enabled = false;

        if (enemyType != Type.D)
            Invoke("ChaseStart", spawnTime);
    }

    public virtual void ColorChange(Renderer[] renderer)
    {
        foreach (MeshRenderer mesh in renderer)
            mesh.material.color = Color.gray;
    }

    public void SetIsDestoryFalse()
    {
        isDestroy = false;
    }

    public bool GetIsDead()
    {
        return isDead;
    }
}
