using System.Collections;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.PlayerLoop;

public class BossRock : Bullet
{
    [Header("Options")]
    [SerializeField] private float speed; // ������Ʈ�� �����̴� �ӵ�
    [SerializeField] private float rollingStartTime; // speed��ŭ �����̱� �����ϴ� �ð�
    [SerializeField] private float scaleUpTime; // Ŀ���µ� �ɸ��� �ð�
    [SerializeField] private GameManager gm;
    [SerializeField] private GameObject bossRockZone;
    [SerializeField] private float bossRockFallDelay = 3f;


    private Rigidbody rigid;
    private float angularPower = 2f;
    private bool isFall;
    private float spawnTime;
    private float realSpawnTime;
    private bool isSpawnBossRock;
    private bool _returned;

    [SerializeField] private Transform player;
    [SerializeField] private Transform meshObj; //Mesh Object ���� (�ڽ�)
    [SerializeField] private float fallSpeed;
    [SerializeField] private float targetY;

    public GameManager Gm => gm;
    public float TarGetY => targetY;
    public void ReturnToPoolOnce()
    {
        if (_returned) return;
        _returned = true;

        // �ʿ��ϸ� ���⼭ ���� ����
        StopAllCoroutines();
        if (bossRockZone != null)
            bossRockZone.SetActive(false);

        EnemyBulletObejctPool.Instance.ReturnBossRockPool(this);
    }

    private void Awake()
    {
        rigid = GetComponent<Rigidbody>();
        realSpawnTime = spawnTime;
        //�ڽ� Mesh Object �ڵ� ã�� (������ ���� ����)
        if (meshObj == null && transform.childCount > 0)
            meshObj = transform.GetChild(0);
    }

    public void ReSetState()
    {
        transform.position = player.position + new Vector3(0f, targetY, 0f);
        isRock = true;
        isFall = false;
        realSpawnTime = 0f;
        if (rigid != null)
            rigid.linearVelocity = Vector3.zero;

        if (player != null)
            transform.position = player.position + new Vector3(0f, targetY, 0f);

        StopAllCoroutines();
        StartCoroutine(GainPowerTimer());
    }

    public void StartBossRockZone()
    {
        if (bossRockZone == null || player == null) return;

        Vector3 targetPosition = player.position + new Vector3(0f, targetY - 3, 0f);
        bossRockZone.gameObject.SetActive(true);
        bossRockZone.transform.position = targetPosition;
    }

    public IEnumerator GainPowerTimer()
    {
        yield return new WaitForSeconds(scaleUpTime);
    }


    private void Update()
    {
        if(bossRockZone != null)
            StartBossRockZone();
        if (!isFall)
        {
            if (player != null)
                transform.position = player.position + new Vector3(0f, targetY, 0f);
        }
        else
        {
            var v = rigid.linearVelocity;
            v.y = Mathf.Max(v.y, -20f); // �ִ� ���� �ӵ� 10 ����
            rigid.linearVelocity = v;
        }

        //�ڽ� Mesh�� ��� ȸ�� (�ð� ȿ��)
        if (meshObj != null)
        {
            meshObj.Rotate(Vector3.right * angularPower * 50f * Time.deltaTime);
        }

        if (EnemyObjectPool.Instance.GetEnemyType(Enemy.Type.D).CurHealth == 0)
        {
            EnemyBulletObejctPool.Instance.ReturnBossRockPool(gameObject.GetComponent<BossRock>());
            //ReturnToPoolOnce();
            return;
        }

        realSpawnTime += Time.deltaTime;

        // 5�� ������ ī�޶� ȸ�� �˸�
        //if (realSpawnTime >= bossRockFallDelay - 2f)
        //{
        //    if (gm != null)
        //    {
        //        gm.SetCameraX(); // GameManager���� Player ī�޶� 45���� �ٷ� ����
        //    }
        //}

        if (realSpawnTime >= bossRockFallDelay)
        {
            isFall = true;
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Floor"))
        {
            EnemyBulletObejctPool.Instance.ReturnBossRockPool(gameObject.GetComponent<BossRock>());
        }
    }

    public void SetGameManager(GameManager gm)
    {
        this.gm = gm;
    }

    public void SetBossRockZone(GameObject bossRockZone)
    {
        this.bossRockZone = bossRockZone;
    }

    public void SetIsSpawnBossRock(bool isSpawnBossRock)
    {
        this.isSpawnBossRock = isSpawnBossRock;
    }

    public GameObject GetBossRockZone()
    {
        return bossRockZone;
    }

    public void SetPlayer(Transform player)
    {
        this.player = player;
    }
}